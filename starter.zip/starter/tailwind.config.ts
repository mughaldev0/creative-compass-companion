import type { Config } from "tailwindcss";

export default {
  darkMode: ["selector", '[data-theme="dark"]'],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)", surface: "var(--surface)", "surface-hi": "var(--surface-hi)",
        ink: "var(--ink)", muted: "var(--ink-muted)", "blue-ink": "var(--blue-ink)",
        accent: "var(--accent)", "on-accent": "var(--on-accent)", line: "var(--control-line)",
        navy: "var(--navy)", "brand-blue": "var(--brand-blue)", "deep-blue": "var(--deep-blue)",
      },
      borderRadius: { control: "12px", card: "20px" },
      fontFamily: { display: ["Montserrat", "system-ui", "sans-serif"], body: ['"Public Sans"', "system-ui", "sans-serif"] },
    },
  },
} satisfies Config;
