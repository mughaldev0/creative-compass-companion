import { useLayoutEffect, type RefObject } from "react";
import { gsap, ScrollTrigger, MQ } from "@/lib/motion";

/** One shared reveal preset. Mark elements with data-reveal. Same distance and duration everywhere. */
export function useReveal(scope: RefObject<HTMLElement>) {
  useLayoutEffect(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ.motionOk, () => {
      const els = gsap.utils.toArray<HTMLElement>("[data-reveal]", root);
      gsap.set(els, { opacity: 0, y: 24 });
      ScrollTrigger.batch(els, {
        start: "top 88%",
        once: true,
        onEnter: (batch) => gsap.to(batch, { opacity: 1, y: 0, duration: 0.6, ease: "power2.out", stagger: 0.08, overwrite: true }),
      });
    });
    return () => mm.revert();
  }, [scope]);
}
