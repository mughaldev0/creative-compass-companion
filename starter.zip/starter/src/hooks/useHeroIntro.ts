import { useLayoutEffect, type RefObject } from "react";
import { gsap, MQ } from "@/lib/motion";

/** Hero intro, once, about 1.1s. Children need data-hero="headline|lead|actions|visual". */
export function useHeroIntro(scope: RefObject<HTMLElement>) {
  useLayoutEffect(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ.motionOk, () => {
      const q = (k: string) => root.querySelector(`[data-hero="${k}"]`);
      const tl = gsap.timeline({ defaults: { ease: "power3.out", duration: 0.5 } });
      tl.from(q("headline"), { y: 28, opacity: 0 })
        .from(q("lead"), { y: 20, opacity: 0 }, "-=0.3")
        .from(q("actions"), { y: 16, opacity: 0 }, "-=0.3")
        .from(q("visual"), { y: 24, opacity: 0 }, "-=0.35");
    });
    return () => mm.revert();
  }, [scope]);
}
