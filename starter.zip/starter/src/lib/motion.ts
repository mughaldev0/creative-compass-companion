import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import type Lenis from "lenis";

gsap.registerPlugin(ScrollTrigger);

let lenisInstance: Lenis | null = null;
export const setLenis = (l: Lenis | null) => { lenisInstance = l; };
export const getLenis = () => lenisInstance;

export const MQ = {
  motionOk: "(prefers-reduced-motion: no-preference)",
  desktopMotion: "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
};

export { gsap, ScrollTrigger };
