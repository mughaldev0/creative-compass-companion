// Single source of truth for content. Empty values are hidden in the UI, never invented.
// Items marked CONFIRM came from the AI reference and need the owner's approval.

export type Course = {
  slug: "web-development" | "vibe-coding";
  title: string;
  summary: string;
  level: string;      // CONFIRM
  duration: string;   // CONFIRM
  price: number;      // CONFIRM (PKR)
  discountPrice: number | null; // CONFIRM (PKR)
  outcomes: string[];
  roadmap: string[];
};

export const site = {
  name: "Rare Skill Academy",
  tagline: "Learn. Practice. Build.",
  announcement: { text: "", href: "" },
  contact: { email: "", phone: "", whatsapp: "", city: "" },
  social: { youtube: "", github: "", linkedin: "", instagram: "", x: "", discord: "" },
  offerEndsAt: "" as string, // YYYY-MM-DD. Empty: no countdown, no "limited time" wording.
  stats: [] as { label: string; value: string; source: string }[], // only real, sourced numbers
};

export const courses: Course[] = [
  {
    slug: "web-development",
    title: "Web Development",
    summary: "Learn modern web development with HTML, CSS, JavaScript, React and more.",
    level: "Beginner to Advanced",
    duration: "8+ weeks",
    price: 4999,
    discountPrice: 2999,
    outcomes: ["HTML", "CSS", "JavaScript", "React.js", "Node.js", "Express.js", "MongoDB", "Full-stack development", "Practical projects"],
    roadmap: ["Web basics (HTML, CSS)", "JavaScript", "React.js", "Backend (Node.js and APIs)", "Final project"],
  },
  {
    slug: "vibe-coding",
    title: "Vibe Coding",
    summary: "Build faster with AI. Learn vibe coding using the latest AI tools.",
    level: "Beginner to Advanced",
    duration: "6+ weeks",
    price: 4999,
    discountPrice: 2999,
    outcomes: ["AI-assisted development", "AI coding tools", "Prompt engineering", "Website development using AI", "Working with AI coding agents", "Building real-world projects"],
    roadmap: ["What vibe coding is", "AI coding tools", "Prompt engineering", "Building websites with AI", "Working with AI coding agents", "Final project"],
  },
];

export const processSteps = [
  "Select your course",
  "Complete enrollment",
  "Get access to the student portal",
  "Attend classes",
  "Complete assignments",
  "Receive performance feedback",
];

export const whyUs = [
  { title: "Practical learning", line: "You write code in every class." },
  { title: "Industry-relevant skills", line: "The stack matches what teams hire for." },
  { title: "Project-based learning", line: "Each course ends with a project you can show." },
  { title: "Expert guidance", line: "An instructor reviews your work." },
  { title: "Real-world assignments", line: "Tasks look like real job tasks." },
  { title: "Student performance monitoring", line: "Your instructor records your progress and remarks." },
];

/** Computed, never typed by hand. */
export const discountPercent = (c: Course): number | null =>
  c.discountPrice && c.discountPrice < c.price ? Math.round((1 - c.discountPrice / c.price) * 100) : null;

export const formatPKR = (n: number) => `PKR ${n.toLocaleString("en-PK")}`;

export const offerIsLive = () =>
  site.offerEndsAt !== "" && new Date(site.offerEndsAt + "T23:59:59") > new Date();
