import { Link } from "react-router-dom";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost";
const styles: Record<Variant, string> = {
  primary: "clay-puffy control font-semibold",
  secondary: "clay-raised-sm control font-semibold text-ink",
  ghost: "font-semibold text-blue-ink underline-offset-4 hover:underline",
};
const base = "press inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 px-5 py-2.5 disabled:cursor-not-allowed disabled:opacity-50";

type Common = { variant?: Variant; children: ReactNode; className?: string };
type AsButton = Common & ButtonHTMLAttributes<HTMLButtonElement> & { to?: undefined };
type AsLink = Common & { to: string; onClick?: () => void };

export function Button(props: AsButton | AsLink) {
  const { variant = "primary", className = "", children } = props;
  const cls = `${base} ${styles[variant]} ${className}`;
  if (props.to !== undefined) {
    return <Link to={props.to} className={cls} onClick={props.onClick}>{children}</Link>;
  }
  const { to: _to, variant: _v, className: _c, children: _ch, ...rest } = props;
  return <button type="button" {...rest} className={cls}>{children}</button>;
}
