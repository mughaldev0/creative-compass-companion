import { useLayoutEffect, useRef, useState } from "react";
import { gsap, ScrollTrigger, MQ } from "@/lib/motion";
import { processSteps } from "@/data/site";

/** Desktop: pinned, steps through six items on scroll. Mobile and reduced motion: plain list. */
export function LearningProcess() {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const mm = gsap.matchMedia();
    mm.add(MQ.desktopMotion, () => {
      const st = ScrollTrigger.create({
        trigger: el, start: "top top", end: `+=${processSteps.length * 50}%`, pin: true, scrub: true,
        onUpdate: (self) => setActive(Math.min(processSteps.length - 1, Math.floor(self.progress * processSteps.length))),
      });
      return () => st.kill();
    });
    return () => mm.revert();
  }, []);

  return (
    <section ref={root} aria-labelledby="process-title" className="mx-auto max-w-6xl px-4 py-20 lg:flex lg:min-h-screen lg:items-center">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
        <h2 id="process-title">From first click to feedback, in six steps</h2>
        <ol className="space-y-4">
          {processSteps.map((s, i) => (
            <li key={s} aria-current={i === active ? "step" : undefined}
                className={`${i === active ? "clay-pressed" : ""} flex gap-4 rounded-control px-4 py-3 transition-opacity duration-200 lg:opacity-60 lg:aria-[current=step]:opacity-100`}>
              <span className="font-display text-xl font-extrabold text-blue-ink">{i + 1}</span>
              <span>{s}</span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
