import { useTheme } from "@/context/ThemeContext";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const dark = theme === "dark";
  return (
    <button
      type="button"
      role="switch"
      aria-checked={dark}
      aria-label="Dark mode"
      onClick={toggleTheme}
      className="clay-pressed control relative inline-flex h-9 w-16 shrink-0 cursor-pointer items-center px-1"
    >
      <span
        aria-hidden="true"
        className="clay-raised-sm grid h-7 w-7 place-items-center text-[11px] font-bold text-blue-ink transition-transform duration-200 motion-reduce:transition-none"
        style={{ transform: dark ? "translateX(28px)" : "translateX(0)", borderRadius: 9999 }}
      >
        {dark ? "D" : "L"}
      </span>
    </button>
  );
}
